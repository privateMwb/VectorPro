#pragma once

#include "helper.h"

#include <cctype>
#include <filesystem>
#include <string>
#include <unordered_map>
#include <vector>

struct BenchSuite {
    std::string id;
    std::string category;
    std::string name;
    void (*run)();
};

inline std::vector<BenchSuite>& bench_registry() {
    static std::vector<BenchSuite> registry;
    return registry;
}

inline std::unordered_map<std::string, int>& category_counters() {
    static std::unordered_map<std::string, int> counters;
    return counters;
}

struct BenchRegistrar {
    BenchRegistrar(const char* file, void (*run)()) {
        auto path = std::filesystem::path(file);

        std::string category = path.parent_path().filename().string();

        char prefix = std::toupper(static_cast<unsigned char>(category.front()));

        int number = ++category_counters()[category];

        bench_registry().push_back({std::string(1, prefix) + std::to_string(number), category,
                                    prettify(path.stem().string()), run});
    }
};

struct BenchmarkResult {
    std::string name;
    std::string library;
    std::string operation;

    std::uint64_t total_ns;
    std::size_t iterations;
    double ns_per_op;
};

inline VectorPro::Vector<BenchmarkResult>& benchmark_results() {
    static VectorPro::Vector<BenchmarkResult> results;
    return results;
}
